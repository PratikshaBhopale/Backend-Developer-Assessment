from flask import Flask, jsonify, request, abort
import json
import os

app = Flask(__name__)

DATA_FILE = os.path.join("data", "customers.json")

def load_customers():
    with open(DATA_FILE, "r") as file:
        return json.load(file)

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "healthy"})

@app.route("/api/customers", methods=["GET"])
def get_customers():
    customers = load_customers()

    page = int(request.args.get("page", 1))
    limit = int(request.args.get("limit", 10))

    start = (page - 1) * limit
    end = start + limit

    paginated_customers = customers[start:end]

    return jsonify({
        "data": paginated_customers,
        "total": len(customers),
        "page": page,
        "limit": limit
    })

@app.route("/api/customers/<string:customer_id>", methods=["GET"])
def get_customer_by_id(customer_id):
    customers = load_customers()

    for customer in customers:
        if customer["customer_id"] == customer_id:
            return jsonify(customer)

    abort(404, description="Customer not found")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
