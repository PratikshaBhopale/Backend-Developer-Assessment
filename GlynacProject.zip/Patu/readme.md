# Patu Project

This project is a **microservice setup** consisting of:

1. **FastAPI Pipeline Service** (`fastapi-pipeline`)
2. **Flask Mock Server** (`flask-mock-server`)
3. **PostgreSQL Database** (`postgres-db`)

The project uses **Docker and Docker Compose** to run all services together.

---

## Table of Contents

- [Technologies](#technologies)
- [Project Structure](#project-structure)
- [Setup and Run](#setup-and-run)
- [API Endpoints](#api-endpoints)
- [Environment Variables](#environment-variables)
- [Troubleshooting](#troubleshooting)

---

## Technologies

- **Python 3.10** (Flask and FastAPI)
- **Flask** (Mock Server)
- **FastAPI** (Pipeline Service)
- **PostgreSQL 15**
- **Docker & Docker Compose**

---

## Project Structure

